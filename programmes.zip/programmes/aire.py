pi = 3.1415926535897932384626

# fonction qui renvoie l'aire d'un disque
def disque(rayon):
    return (pi*rayon**2)

# fonction qui renvoie l'aire d'un rectangle
def rectangle(largeur, longueur):
    return longueur*largeur

# fonction qui renvoie l'aire d'un rectangle
def triangle(base, hauteur):
    return base*(1/2)*hauteur

print(disque(5))
print(rectangle(2,5))
print(triangle(2,7))