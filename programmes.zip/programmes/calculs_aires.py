from os import chdir
chdir("/media/common/NSI/programmes")
from aire import *
print(pi)
import aire
help(aire.disque)